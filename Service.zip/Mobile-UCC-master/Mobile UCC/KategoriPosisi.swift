//
//  KategoriPosisi.swift
//  Mobile UCC
//
//  Created by MacbookPRO on 10/09/18.
//  Copyright © 2018 LabSE Siskom. All rights reserved.
//

import Foundation

class KategoriPosisi
{
    var id_kategori: String?
    var deskripsi: String?
    
    init(id_kategori: String, deskripsi: String)
    {
        self.id_kategori = id_kategori
        self.deskripsi = deskripsi
    }
}
