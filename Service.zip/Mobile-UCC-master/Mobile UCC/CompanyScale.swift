//
//  CompanyScale.swift
//  Mobile UCC
//
//  Created by MacbookPRO on 15/09/18.
//  Copyright © 2018 LabSE Siskom. All rights reserved.
//

import Foundation

class CompanyScale
{
    var id_skala: String?
    var deskripsi: String?
    
    init(id_skala: String, deskripsi: String)
    {
        self.id_skala = id_skala
        self.deskripsi = deskripsi
    }
}
