# JobBot
Safari extension with a script which applies to all job listings featuring a "Quick Apply" button in ziprecruiter.com
