//
//  Industri.swift
//  Mobile UCC
//
//  Created by MacbookPRO on 10/09/18.
//  Copyright © 2018 LabSE Siskom. All rights reserved.
//

import Foundation

class Industri
{
    var id_bidang: String?
    var deskripsi: String?
    
    init(id_bidang: String, deskripsi: String)
    {
        self.id_bidang = id_bidang
        self.deskripsi = deskripsi
    }
}
