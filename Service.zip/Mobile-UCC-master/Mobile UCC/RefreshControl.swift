//
//  RefreshControl.swift
//  Mobile UCC
//
//  Created by MacbookPRO on 07/11/18.
//  Copyright © 2018 LabSE Siskom. All rights reserved.
//

/*import Foundation

class RefreshControl {
   
    lazy var refresher: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        //refreshControl.backgroundColor = UIColor.clear
        refreshControl.tintColor = .white
        
        /*let loadImage = UIImageView()
        loadImage.image = UIImage(named: "loading")
        //loadImage.frame = refreshControl.bounds.offsetBy(dx: self.view.frame.size.width / 2 - 20, dy: 10) // half the width of the refreshImage,)
        
        loadImage.frame.size.width = 40 // Whatever width you want
        loadImage.frame.size.height = 40 // Whatever height you want
        refreshControl.insertSubview(loadImage, at: 0)*/
        
        return refreshControl
    }()

    /*var viewController: UIViewController?
    var tableView: UITableView?
    @objc var populate = {(()->Void?).self}
    
    init(viewController: UIViewController, tableView: UITableView) {
        self.viewController = viewController
        self.tableView = tableView
    }
    
    func addRefreshControl() {
        refresher.attributedTitle = NSAttributedString(string: "Loading")
        refresher.addTarget(self.viewController, action: #selector(getter: populate), for: UIControl.Event.valueChanged)
    }*/
    
    
}*/

