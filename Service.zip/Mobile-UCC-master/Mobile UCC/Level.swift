//
//  Level.swift
//  Mobile UCC
//
//  Created by MacbookPRO on 15/09/18.
//  Copyright © 2018 LabSE Siskom. All rights reserved.
//

import Foundation

class Level
{
    var id_level: String?
    var deskripsi: String?

    init(id_level: String, deskripsi: String)
    {
        self.id_level = id_level
        self.deskripsi = deskripsi
    }
}
