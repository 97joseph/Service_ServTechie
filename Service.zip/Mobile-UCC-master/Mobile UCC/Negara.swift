//
//  Negara.swift
//  Mobile UCC
//
//  Created by MacbookPRO on 13/03/18.
//  Copyright © 2018 LabSE Siskom. All rights reserved.
//

import Foundation

class Negara
{
    var id_negara: String?
    var nama_negara: String?
    
    init(id_negara: String, nama_negara: String)
    {
        self.id_negara = id_negara
        self.nama_negara = nama_negara
    }
}
