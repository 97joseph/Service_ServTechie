//
//  Kota.swift
//  Mobile UCC
//
//  Created by MacbookPRO on 19/03/18.
//  Copyright © 2018 LabSE Siskom. All rights reserved.
//

import Foundation

class Kota
{
    var id_kota: String?
    var nama_kota: String?
    
    init(id_kota: String, nama_kota: String)
    {
        self.id_kota = id_kota
        self.nama_kota = nama_kota
    }
}
